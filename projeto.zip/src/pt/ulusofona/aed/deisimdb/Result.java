package pt.ulusofona.aed.deisimdb;

public class Result {
    Boolean success;
    String result;
    String error;
}
